import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] idades = new int[40];
        char[] opinioes = new char[40];
        int totalOtimo = 0, totalRuim = 0, totalPessimo = 0;
        int somaIdadesRuim = 0, somaNotas = 0;

        for (int i = 0; i < 40; i++) {
            System.out.println("Espectador " + (i + 1) + ":");
            System.out.print("Idade: ");
            idades[i] = scanner.nextInt();
            System.out.print("Opinião (A/B/C/D/E): ");
            opinioes[i] = scanner.next().charAt(0);

            if (opinioes[i] == 'A') {
                totalOtimo++;
                somaNotas += 5;
            } else if (opinioes[i] == 'B') {
                somaNotas += 4;
            } else if (opinioes[i] == 'C') {
                somaNotas += 3;
            } else if (opinioes[i] == 'D') {
                totalRuim++;
                somaIdadesRuim += idades[i];
                somaNotas += 2;
            } else if (opinioes[i] == 'E') {
                totalPessimo++;
                somaNotas += 1;
            }
        }

        double porcentagemPessimo = ((double) totalPessimo / 40) * 100;
        double mediaIdadesRuim = totalRuim > 0 ? (double) somaIdadesRuim / totalRuim : 0;
        double mediaGeralNotas = (double) somaNotas / 40;

        System.out.println("Quantidade de respostas 'Ótimo': " + totalOtimo);
        System.out.println("Média de idade das pessoas que responderam 'Ruim': " + mediaIdadesRuim);
        System.out.println("Porcentagem de respostas 'Péssimo': " + porcentagemPessimo + "%");
        System.out.println("Média geral das notas: " + mediaGeralNotas);

        scanner.close();
    }
}
